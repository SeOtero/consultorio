package ar.org.centro8.curso.java.consultorio.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.consultorio.connectors.Connector;
import ar.org.centro8.curso.java.consultorio.entities.Medico;

public class MedicoRepository {
    
    private Connection conn = Connector.getConnection();
    
    public void save(Medico medico) {
        if (medico == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into medicos (nombre, apellido, especialidad) values (?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, medico.getNombre());
            ps.setString(2, medico.getApellido());
            ps.setString(3, medico.getEspecialidad());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                medico.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Medico> getAll() {
        List<Medico> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from medicos")) {
            while (rs.next()) {
                list.add(new Medico(
                        rs.getInt("id"),            // id
                        rs.getString("nombre"),     // nombre
                        rs.getString("apellido"),   // apellido
                        rs.getString("especialidad")   // especialidad                  
                ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Medico getById(int id) {
        return getAll()
                .stream()
                .filter(m -> m.getId() == id)
                .findFirst()
                .orElse(new Medico());
    }

    public List<Medico>getLikeApellido(String apellido){
        if(apellido==null) return new ArrayList();
        return getAll()
                    .stream()
                    .filter(a->a.getApellido().toLowerCase().contains(apellido.toLowerCase()))
                    .toList();     
    }
}

