package ar.org.centro8.curso.java.consultorio.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.consultorio.connectors.Connector;
import ar.org.centro8.curso.java.consultorio.entities.Turno;
import ar.org.centro8.curso.java.consultorio.enums.Hora;

public class TurnoRepository {
    private Connection conn = Connector.getConnection();

    public void save(Turno turno) {
        if (turno == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into turnos (medico_id,paciente_id,fecha,hora) values (?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, turno.getMedico_id());
            ps.setInt(2, turno.getPaciente_id());
            ps.setString(3, turno.getFecha());
            ps.setString(4, turno.getHora().toString());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                turno.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Turno> getAll() {
        List<Turno> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from turnos")) {
            while (rs.next()) {
                list.add(new Turno(
                        rs.getInt("id"),
                        rs.getInt("medico_id"),
                        rs.getInt("paciente_id"),
                        rs.getString("fecha"), 
                        Hora.valueOf(rs.getString("hora"))             
                ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Turno getById(int id) {
        return getAll()
                .stream()
                .filter(t -> t.getId() == id)
                .findFirst()
                .orElse(new Turno());
    }

    public List<Turno>getLikeFecha(String fecha){
        if(fecha==null) return new ArrayList();
        return getAll()
                    .stream()
                    .filter(t->t.getFecha().toLowerCase().contains(fecha.toLowerCase()))
                    .toList();     
    }
}
