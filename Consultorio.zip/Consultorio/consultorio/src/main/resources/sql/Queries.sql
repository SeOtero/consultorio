use consultorio; 
-- busqueda de toda la base
 select * from turnos t join pacientes p on t.paciente_id=p.id 
						join medicos m on t.medico_id=m.id;
                        
-- busqueda turno por nombre
select p.nombre,p.apellido,fecha,hora, especialidad from turnos t join pacientes p on t.paciente_id=p.id 
						join medicos m on t.medico_id=m.id where p.nombre='sebastian';

-- busqueda turno por medico
select m.nombre,m.apellido,fecha,hora from turnos t join pacientes p on t.paciente_id=p.id 
						join medicos m on t.medico_id=m.id where m.apellido='demedi';
                        
-- cantidad de turnos por fecha
select  fecha,count(t.id) from turnos t join pacientes p on t.paciente_id=p.id 
						join medicos m on t.medico_id=m.id group by t.fecha;
                        
-- cantidad de turnos por especialidad 
select  fecha,especialidad, count(especialidad) from turnos t join pacientes p on t.paciente_id=p.id 
						join medicos m on t.medico_id=m.id group by t.fecha;
                        
--
					