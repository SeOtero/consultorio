drop database if exists consultorio; 
 create database consultorio; 
 use consultorio; 
  
 create table turnos( 
         id int auto_increment primary key, 
     medico_id int not null, 
     paciente_id int not null, 
     fecha date, 
     hora enum('Turno_1400','Turno_1430','Turno_1500','Turno_1530','Turno_1600','Turno_1630','Turno_1700', 'Sbt_1715', 'Sbt_1730'),
      CONSTRAINT turnoUnico UNIQUE (fecha, hora, medico_id)
      
 ); 
  
 create table pacientes( 
         id int auto_increment primary key, 
     nombre varchar(20) not null, 
     apellido varchar(20) not null, 
     edad int check(edad between 18 and 120), 
     telefono varchar(20), 
     mail varchar(40) 
 ); 
  
 alter table turnos 
         add constraint FK_pacientes_turnos 
     foreign key(paciente_id) 
     references pacientes(id); 
      
 create table medicos( 
         id int auto_increment primary key, 
     nombre varchar(20) not null, 
     apellido varchar(20) not null, 
     especialidad varchar(20) 
      
 ); 
  
 alter table turnos 
         add constraint FK_medicos_turnos 
     foreign key(medico_id) 
     references medicos(id);