package ar.org.centro8.curso.java.consultorio.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.consultorio.connectors.Connector;
import ar.org.centro8.curso.java.consultorio.entities.Paciente;

public class PacienteRepository {
    private Connection conn = Connector.getConnection();
    
    public void save(Paciente paciente) {
        if (paciente == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into pacientes (nombre, apellido, edad, telefono, mail) values (?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, paciente.getNombre());
            ps.setString(2, paciente.getApellido());
            ps.setInt(3, paciente.getEdad());
            ps.setInt(4, paciente.getTelefono());
            ps.setString(5, paciente.getMail());

            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                paciente.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Paciente> getAll() {
        List<Paciente> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from pacientes")) {
            while (rs.next()) {
                list.add(new Paciente(
                        rs.getInt("id"),            // id
                        rs.getString("nombre"),     // nombre
                        rs.getString("apellido"),   // apellido
                        rs.getInt("edad"),           // edad
                        rs.getInt("telefono"),       //telefono
                        rs.getString("mail")        //mail
                ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Paciente getById(int id) {
        return getAll()
                .stream()
                .filter(p -> p.getId() == id)
                .findFirst()
                .orElse(new Paciente());
    }

    public List<Paciente>getLikeApellido(String apellido){
        if(apellido==null) return new ArrayList();
        return getAll()
                    .stream()
                    .filter(a->a.getApellido().toLowerCase().contains(apellido.toLowerCase()))
                    .toList();     
    }
    
}
