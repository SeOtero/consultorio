use consultorio; 
 -- insert pacientes 
 insert into pacientes(nombre,apellido,edad,telefono,mail) values('Sebastian','Otero',27,'1121479876','sox@gmail.com'); 
 insert into pacientes(nombre,apellido,edad,telefono,mail) values('Lucian','Cani',27,'1134567546','lcx@gmail.com'); 
 insert into pacientes(nombre,apellido,edad,telefono,mail) values('Lucas','Son',27,'1121421346','lucsx@gmail.com'); 
 insert into pacientes(nombre,apellido,edad,telefono,mail) values('Artuan','Cañon',27,'1155579876','articuno@gmail.com'); 
 insert into pacientes(nombre,apellido,edad,telefono,mail) values('Manpa','Utasso',27,'1199999876','manipa@gmail.com');
 insert into pacientes(nombre,apellido,edad,telefono,mail) values('Gaspar','Montoca',23,'1179797776','gaspamo@gmail.com');
 insert into pacientes(nombre,apellido,edad,telefono,mail) values('Jeremias','Goros',32,'1123219876','jegoria@gmail.com'); 
 insert into pacientes(nombre,apellido,edad,telefono,mail) values('Lucas','Lias',47,'1178987631','Luksle@gmail.com'); 
  
  
 -- insert medicos 
 insert into medicos(nombre,apellido,especialidad) values('Patricia','Demedi','Clinico'); 
 insert into medicos(nombre,apellido,especialidad) values('Jose','Iannu','Ginecologo'); 
 insert into medicos(nombre,apellido,especialidad) values('Sergio','Ester','Cardiologo'); 
 insert into medicos(nombre,apellido,especialidad) values('Daniel','Richard','Proctologo'); 
 insert into medicos(nombre,apellido,especialidad) values('Paola','Gianluchi','Endocrinologa');
 insert into medicos(nombre,apellido,especialidad) values('Nerina','Richir','Neurologo');
 
  
  
 -- insert turnos 
  
 
 insert into turnos(medico_id,paciente_id,fecha,hora) values(2,2,'2023-05-20','Turno_1400'); 
 insert into turnos(medico_id,paciente_id,fecha,hora) values(3,1,'2023-05-20','Turno_1430'); 
 insert into turnos(medico_id,paciente_id,fecha,hora) values(4,4,'2023-05-21','Turno_1500'); 
 insert into turnos(medico_id,paciente_id,fecha,hora) values(5,5,'2023-05-17','Turno_1530');
 insert into turnos(medico_id,paciente_id,fecha,hora) values(1,6,'2023-05-25','Turno_1500');
 insert into turnos(medico_id,paciente_id,fecha,hora) values(2,8,'2023-05-17','Turno_1400');
