package ar.org.centro8.curso.java.consultorio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsultorioApplicationTests {

	@Test
	void contextLoads() {
	}

}
