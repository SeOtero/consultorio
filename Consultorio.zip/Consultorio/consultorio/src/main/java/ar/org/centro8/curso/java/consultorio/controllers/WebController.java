package ar.org.centro8.curso.java.consultorio.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.curso.java.consultorio.entities.Medico;
import ar.org.centro8.curso.java.consultorio.entities.Paciente;
import ar.org.centro8.curso.java.consultorio.entities.Turno;
import ar.org.centro8.curso.java.consultorio.repositories.MedicoRepository;
import ar.org.centro8.curso.java.consultorio.repositories.PacienteRepository;
import ar.org.centro8.curso.java.consultorio.repositories.TurnoRepository;


@Controller
public class WebController {
    
    private TurnoRepository turnoRepository=new TurnoRepository();
    private PacienteRepository pacienteRepository=new PacienteRepository();
    private MedicoRepository medicoRepository=new MedicoRepository();
    private String mensajeTurno="Agende un nuevo Turno";
    private String mensajePaciente="Ingrese un nuevo Paciente";
    private String mensajeMedico="Ingrese un nuevo Medico";

    @GetMapping("/")
    public String getIndex(){
        return "index";
    }

    @GetMapping("/turnos")
    public String getTurnos(@RequestParam(name="buscarFecha", required = false, defaultValue="") String buscarFecha,
                                 Model model){
        model.addAttribute("mensajeTurno", mensajeTurno);
        model.addAttribute("turno", new Turno());
        model.addAttribute("likeFecha", turnoRepository.getLikeFecha(buscarFecha));
        model.addAttribute("turnos", turnoRepository.getAll());
        model.addAttribute("pacientes", pacienteRepository.getAll());
        model.addAttribute("medicos", medicoRepository.getAll());

        return "turnos";
    }

    @GetMapping("/pacientes")
    public String getPacientes(@RequestParam(name="buscarApellido", required = false, defaultValue="") String buscarApellido,
                    Model model){
        model.addAttribute("mensajePaciente", mensajePaciente);
        model.addAttribute("paciente", new Paciente());
        model.addAttribute("likeApellido", pacienteRepository.getLikeApellido(buscarApellido));
        model.addAttribute("turnos", turnoRepository.getAll());
        return "pacientes";
    }

    @GetMapping("/medicos")
    public String getMedicos(@RequestParam(name="buscarApellido", required = false, defaultValue="") String buscarApellido,
                    Model model){
        model.addAttribute("mensajeMedico", mensajeMedico);
        model.addAttribute("medico", new Medico());
        model.addAttribute("likeApellido", medicoRepository.getLikeApellido(buscarApellido));
        model.addAttribute("turnos", turnoRepository.getAll());
        return "medicos";
    }

    @PostMapping("/saveTurno")
    public String save(@ModelAttribute Turno turno){
        try {
            turnoRepository.save(turno);
            mensajeTurno="Se guardo el turno id: "+turno.getId();
        } catch (Exception e) {
            mensajeTurno="Ocurrio un error";
        }
        return "redirect:turnos";
    }

    @PostMapping("/savePaciente")
    public String save(@ModelAttribute  Paciente paciente){
        try {
            pacienteRepository.save(paciente);
            mensajePaciente="Se guardo el paciente id: "+paciente.getId();
        } catch (Exception e) {
            mensajePaciente="Ocurrio un error";
        }
        return "redirect:pacientes";
    }

    @PostMapping("/saveMedico")
    public String save(@ModelAttribute Medico medico){
        try {
            medicoRepository.save(medico);
            mensajeMedico="Se guardo el medico id: "+medico.getId();
        } catch (Exception e) {
            mensajeMedico="Ocurrio un error";
        }
        return "redirect:medicos";
    }
}
