package ar.org.centro8.curso.java.consultorio.test;

import ar.org.centro8.curso.java.consultorio.entities.Medico;
import ar.org.centro8.curso.java.consultorio.entities.Paciente;
import ar.org.centro8.curso.java.consultorio.entities.Turno;
import ar.org.centro8.curso.java.consultorio.enums.Hora;
import ar.org.centro8.curso.java.consultorio.repositories.MedicoRepository;
import ar.org.centro8.curso.java.consultorio.repositories.PacienteRepository;
import ar.org.centro8.curso.java.consultorio.repositories.TurnoRepository;

public class TestRepository {
    public static void main(String[] args) {
        System.out.println("*********************TurnoRepository***************************");
        TurnoRepository tr= new TurnoRepository();

        Turno turno= new Turno(1, 6, "2023-06-08", Hora.Turno_1500);

       tr.save(turno); 

        System.out.println(turno);
        System.out.println("******************GETALL_T************************************************");
        tr.getAll().forEach(System.out::println);

        System.out.println("******************GETID_T******************************");
        System.out.println(tr.getById(2));
        
        System.out.println("******************GETLIKEFECHA_T************************************************");
        tr.getLikeFecha("17").forEach(System.out::println);

        System.out.println("*********************PacienteRepository***************************");
        PacienteRepository pr= new PacienteRepository();

        Paciente paciente= new Paciente("Sebastian", "Otero", 27, 1137038270, "sechootero@gmail.com");
        pr.save(paciente);
        
        System.out.println(paciente);
        System.out.println("******************GETALL_P************************************************");
        pr.getAll().forEach(System.out::println);

        System.out.println("******************GETAPELLIDO_P************************************************");
        pr.getLikeApellido("ot").forEach(System.out::println);
        System.out.println("******************GETID_P************************************************");
        System.out.println(pr.getById(2));

        System.out.println("*********************MedicoRepository***************************");

        MedicoRepository mr= new MedicoRepository();

        Medico medico= new Medico("Matias", "Chingio", "Neurocirugia");
         mr.save(medico);

        System.out.println(medico);
        
        System.out.println("************************GETALL_M******************************************");
        mr.getAll().forEach(System.out::println);
        System.out.println("******************************************************************");

        System.out.println("*********************GETAPELLIDO_M*********************************************");
        mr.getLikeApellido("gio").forEach(System.out::println);
        System.out.println("*********************GETID_M*********************************************");
        System.out.println(mr.getById(6));

    }
}
