package ar.org.centro8.curso.java.consultorio.enums;

public enum Hora {
    Turno_1400,
    Turno_1430,
    Turno_1500,
    Turno_1530,
    Turno_1600,
    Turno_1630,
    Turno_1700, 
    Sbt_1715,
    Sbt_1730
}
