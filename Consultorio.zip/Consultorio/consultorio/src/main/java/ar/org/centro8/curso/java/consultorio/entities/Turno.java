package ar.org.centro8.curso.java.consultorio.entities;

import ar.org.centro8.curso.java.consultorio.enums.Hora;

public class Turno {
    private int id;
    private int medico_id;
    private int paciente_id;
    private String fecha;
    private Hora hora;

    public Turno() {
    }

    public Turno(int medico_id, int paciente_id, String fecha, Hora hora) {
        this.medico_id = medico_id;
        this.paciente_id = paciente_id;
        this.fecha = fecha;
        this.hora = hora;
    }

    public Turno(int id, int medico_id, int paciente_id, String fecha, Hora hora) {
        this.id = id;
        this.medico_id = medico_id;
        this.paciente_id = paciente_id;
        this.fecha = fecha;
        this.hora = hora;
    }

    

    @Override
    public String toString() {
        return "Turno [id=" + id + ", medico_id=" + medico_id + ", paciente_id=" + paciente_id + ", fecha=" + fecha
                + ", hora=" + hora + "]";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMedico_id() {
        return medico_id;
    }

    public void setMedico_id(int medico_id) {
        this.medico_id = medico_id;
    }

    public int getPaciente_id() {
        return paciente_id;
    }

    public void setPaciente_id(int paciente_id) {
        this.paciente_id = paciente_id;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public Hora getHora() {
        return hora;
    }

    public void setHora(Hora hora) {
        this.hora = hora;
    }

    
}


